===========================================================================
Title                   : Outpost Zeta
Filename                : outpostzeta.bsp
Release date            : December 22nd, 2020
Author                  : Max Garay
Email Address           : maxicus.magicus@gmail.com
Other Files By Author   :
Misc. Author Info       : Aspiring game designer currently residing in Chicago

Description             : Congratulations, soldier. Bold and cunning as you are, you've successfully smuggled yourself into the enemy base known as "Outpost Zeta". Now, once you've escaped their shipping & receiving center, you're going to have to fight your way past their defenses and push towards the very heart of the outpost, where our intelligence indicates their sinister Supersoldier program lies in wait. Soldier, you must shut down that program before it's too late! We're counting on you!

Additional Credits to   : * Dumptruck_Ds for his many helpful tutorial videos
* The people of the Quake Mapping Discord for helping me through a wide variety of issues, big and small, over the course of development
* The playtesters who looked at my map at various stages along the way
===========================================================================
* What is included *

New levels              : Yes
Sounds                  : No
Music                   : No
Graphics                : No
Other                   : No
Other files required    :


* Play Information *

Single Player           : Designed for
Cooperative 2-4 Player  : No
Deathmatch 2-4 Player   : No
Difficulty Settings     : Not implemented


* Construction *

Base                    : New from scratch
Build Time              : Approx. 14 cumulative hours of work 
Editor(s) used          : Trenchbroom
Known Bugs              : 
May Not Run With        : 
Tested With             : Quakespasm



* Copyright / Permissions *

Authors MAY use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.

You MAY distribute this file, provided you include this text file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.  I have received permission from the original authors of any
modified or included content in this file to allow further distribution.


* Where to get the file that this text file describes *

Web sites: https://github.com/CharAznable1138/Outpost-Zeta-A-Quake-Singleplayer-Map
FTP sites: